# Changelog

All notable contract changes are recorded here.

## 1.9.0 — 2026-10-31

Product variants on the import event (MINOR release; see the adoption ordering
below before a producer emits `variants`).

- Added `productVariantRefSchema` (`src/schemas/events.ts`): optional `id`, required `sku` (`min 1`, `max 64`, i.e. the `product_variants.sku` column width), `price` (number or numeric string, as everywhere money crosses a `DECIMAL`), optional `effectivePrice`, `stock` (non-negative integer), `imageUrl`, `isActive`. `.strict()` like every other payload.
- `productImportedPayloadSchema` gains `variants?: ProductVariantRef[]` and the `ProductVariantRef` type. cat-008 upserts by `sku` and lets Postgres mint `id` on a first import, which is why `id` is optional.
- `productUpdatedPayloadSchema` is **not** changed. The asymmetry is deliberate: an importer owns variants wholesale, while `product.updated` describes a single edit and has no batch semantics. Adding `variants` there is a separate decision with its own consumer-ordering problem.

**Adoption ordering is part of this release, not an afterthought.** Every payload schema here is `.strict()`, so `parseEventPayload` rejects unknown keys by design. That means `variants` is *not* backward compatible in practice even though the field is optional: a producer that starts emitting `variants` while a consumer still pins 1.8.0 makes that consumer dead-letter every `product.imported` record it sees. The 1.9.0 tarball therefore has to reach **both** `product.imported` consumers — search-svc (which parses the payload through `event-interpreter`) and catalog-svc (cat-008) — before any fixture, importer or producer writes the field. `@ecom/messaging` 0.3.0 widens its peer range to `>=1.9.0 <2` for the same reason.

## 1.8.0 — 2026-10-30

Task-queue schemas and the queue registry (MINOR release, backwards compatible with 1.7.0).

- Added `sendEmailJobSchema` (`src/schemas/jobs.ts`): `template` (`order-confirmation` | `cart-abandoned` | `welcome`), optional `userId`/`orderId`/`cartId`, optional `locale`, required `idempotencyKey`. There is **no** recipient address field — the same PII rule that keeps emails out of the Kafka log keeps them out of SQS; notify-svc resolves the address from the named aggregate.
- Added `processImportRowJobSchema`: `jobId`, `rowNumber` (positive), `source` (`csv` | `json`), `stockMode` (`replace` | `add`), and `row` as a record of scalars.
- Added `emailTemplateSchema`, `importSourceSchema`, `importStockModeSchema`, `importRowValueSchema` and their inferred types.
- Added `src/schemas/queues.ts`: `TASK_QUEUES` (three queues × producer/consumer/`-dlq` twin/`maxReceiveCount: 5`/`visibilityTimeoutSeconds: 60`/`retention: 14d`), `TASK_QUEUE_NAMES`, `TASK_DLQ_NAMES`, `taskQueueNameSchema`, `isTaskQueue()`.
- `resizeImageJobSchema` is unchanged.
- Removed the `reminder.dispatch` queue name, which no producer ever emitted.

**Naming.** Queue names are hyphenated (`notify-send-email`, `import-process-row`, `media-resize-image`) because SQS accepts only alphanumerics, hyphens and underscores — a dot is legal only as a trailing `.fifo`. The dotted spellings used in earlier design notes were not creatable, so they never shipped.

## 1.7.0 — 2026-10-30

Product-card placement and variant contracts (MINOR release, backwards compatible with 1.6.0).

- Added `optionCardPlacementSchema` (`info` | `media` | `brand-hover` | `media-hover-top` | `hidden`) and optional `cardPlacement` on `productCardOptionSchema`, defaulting to `info`.
- Added `cardVariantSchema` (`id`, `sku`, `price`, optional `compareAtPrice`/`imageUrl`, `stock`, `optionValues`).
- Extended `themeProductCardSchema` with the gallery and grid controls: `eyebrow`, `imageNav`, `imageIndicator`, `imageIndicatorPosition`, `imageLoop`, `imageLimit`, `selectionMode`, `selectionEffects`, `colsDesktop`, `colsTablet`, `colsPhone`.

## 1.6.0 — 2026-10-30

Catalog badges and product-card settings (MINOR release, backwards compatible with 1.5.0).

- Added `src/schemas/catalog.ts`: `badgeSchema`, `createBadgeSchema`, `updateBadgeSchema`, `badgeBorderStyleSchema`, `productBadgeAssignmentSchema`, `productBadgeItemSchema`, plus the product-card option schemas `optionDisplayTypeSchema`, `productCardOptionValueSchema`, `productCardOptionSchema` and the `productCardSettingsSchema` alias of `themeProductCardSchema`.
- Added `themeProductCardSchema` to `src/schemas/theme.ts` — the appearance half of the card (layout, media, colours, CTA, typography) — and wired it into `themeSettingsSchema`.
- Deprecated `customBadgeSchema` and `themeBadgesSchema`: catalog badges are now the single source of truth.

## 1.5.0 — 2026-10-30

Media visibility (MINOR release, backwards compatible with 1.4.0).

- Added `mediaVisibilitySchema` (`public` | `private`) and the `MediaVisibility` type.
- Added **optional** `visibility` to `mediaSchema`. Absent means `public`, so every 1.4.0-era record and payload keeps parsing; `private` assets are served only by the authenticated admin file route. cms-003 is the producing change (`cms_media.visibility`, default `public`).

## 1.4.0 — 2026-10-30

Event payload schemas and the topic registry (MINOR release, backwards compatible with 1.3.0).

- Added payload schemas in `src/schemas/events.ts`:
  - `userRegisteredPayloadSchema` — `userId`, optional `displayName`, `registeredAt`. No email: notify-svc resolves it through `GET /internal/users/:id/email`.
  - `cartUpdatedPayloadSchema` — mirrors `buildCartUpdatedEvent`/`toItemDto`: `id` and `addedAt` per line, nullable `userId`, `sessionId`, `variantId`, `productSlug`, `imageUrl`, `variantLabel`.
  - `cartAbandonedPayloadSchema`, `pageViewedPayloadSchema` — target contracts for analytics-svc.
  - `orderCreatedPayloadSchema` — accepts `reservationId: ''` so a resumed checkout validates.
  - `orderStatusUpdatedPayloadSchema` — 8-value `from`/`to`, optional `note`, `actor`, `refundAmount` (string or number), `refundReference`.
  - `orderStatusSchema` — the order lifecycle enum, exported for DTO reuse.
- Added `src/schemas/topics.ts`: `EVENT_TOPICS` (11 topics with producer, consumers, partitions, retention, key, DLQ), `eventTopicSchema`, `eventPayloadSchemas`, `parseEventPayload()`, `parseEventEnvelope()`, `dlqTopicName()`, `isEventTopic()`.

## 1.3.0 — 2026-10-29

Canonical event envelope with a dual-read/dual-write window (MINOR release, backwards compatible with 1.2.0).

- Added optional `type` to `eventEnvelopeSchema`; `type` is the canonical event name and Kafka topic.
- Made `topic` and `eventType` optional legacy fields; at least one of `type`, `topic`, or `eventType` is required.
- Added `canonicalEventEnvelopeSchema` for 2.0.0-ready producers (`type`, `version`, and `idempotencyKey` required).
- Added `readEventEnvelope()` to normalize legacy envelopes to `{id,type,version,timestamp,producer,idempotencyKey,payload}`; `version` defaults to 1 and `idempotencyKey` defaults to `id`.
- Dual-write envelopes must keep `type`, `topic`, and `eventType` in agreement when `type` is present.

## 1.2.0 — 2026-10-28

- Widened search document and result IDs to `varchar(64)` strings.

## 1.1.0 — 2026-10-28

Search domain contracts and event payloads (MINOR release, backwards compatible with 1.0.0).

- Added search DTO schemas: `searchDocumentSchema`, `searchResultItemSchema`, `searchSuggestResponseSchema`, `searchResponseSchema`.
- Added query schemas: `suggestQuerySchema`, `searchQuerySchema`.
- Added ingestion & stats schemas: `ingestSearchDocumentsSchema`, `ingestSearchDocumentsResponseSchema`, `searchStatsSchema`.
- Added Kafka event payload schemas in `src/schemas/events.ts`:
  - `productImportedPayloadSchema`
  - `productUpdatedPayloadSchema`
  - `categoryUpdatedPayloadSchema`
  - enriched `blogUpdatedPayloadSchema` with optional `title`, `excerpt`, `coverUrl`, `publishedAt`, `updatedAt`, `categoryId`.
- Added optional `idempotencyKey` and `version` to `eventEnvelopeSchema`.

## 1.0.0 — 2026-10-28

Initial Phase 2 contract package.

- Added shared primitive schemas: keys, UUIDs, hex colors, internal paths,
  image refs, ISO dates, CMS revision.
- Added CTA schema with max 3 CTAs.
- Added CMS section types: `hero`, `banner`, `featured_products`,
  `category_showcase`, `brand_strip`, `blog_teaser`, `testimonial`.
- Added per-type section content schemas and settings allowlists.
- Added `SECTION_CATALOG` admin governance rules.
- Added section list response and reorder schemas.
